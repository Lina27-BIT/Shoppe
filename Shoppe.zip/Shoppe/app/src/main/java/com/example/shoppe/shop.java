package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class shop extends AppCompatActivity {
    private Button btnpoiscovic;
    private ImageButton btneshe;
    private ImageButton btneshe2;
    private ImageButton btneshe3;
    private ImageButton btnglavn;
    private ImageButton btnizbrn;
    private ImageButton btncarzinca;
    private ImageButton btnprof;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shop);
        btnpoiscovic = findViewById(R.id.poiscovic);
        btneshe = findViewById(R.id.eshe);
        btneshe2 = findViewById(R.id.eshe_2);
        btneshe3 = findViewById(R.id.eshe_3);
        btnglavn = findViewById(R.id.glavn);
        btnizbrn = findViewById(R.id.izbrn);
        btncarzinca = findViewById(R.id.carzinca);
        btnprof = findViewById(R.id.prof);
        btnprof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(shop.this, proffil.class);
                startActivity(intent);
            }
        });
        btnizbrn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(shop.this, izbrannoe.class);
                startActivity(intent);
            }
        });
        btncarzinca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(shop.this, carzina.class);
                startActivity(intent);
            }
        });
    }
}
