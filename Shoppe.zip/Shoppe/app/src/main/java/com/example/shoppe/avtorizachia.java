package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class avtorizachia extends AppCompatActivity {
    private Button btndalee;
    private Button btnotmena2;
    private EditText vvodemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.avtorizachia);
        btndalee = findViewById(R.id.dalee);
        btnotmena2 = findViewById(R.id.otmena2);
        vvodemail = findViewById(R.id.email);
        btndalee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateInputs();
            }
        });
        btnotmena2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(avtorizachia.this, start.class);
                startActivity(intent);
            }
        });
    }
    private void validateInputs(){
        String email = vvodemail.getText().toString().trim();
        if (email.isEmpty()){
            Toast.makeText(this, "Введите почту", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!email.contains("@") || !email.contains(".")){
            Toast.makeText(this,"Введите правильную почту", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(avtorizachia.this, password.class);
        startActivity(intent);
    }

}
