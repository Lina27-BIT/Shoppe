package com.example.shoppe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class nasroica_proffil extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private  ImageButton imnasr_photo;
    private Button btnsohran_izmenenia;
    private ImageButton ibglavn_6;
    private ImageButton ibizbrn_6;
    private ImageButton ibcarzinca_6;
    private ImageButton ibprof_6;
    private EditText textnastroici_imia;
    private EditText textnastroici_email;
    private EditText textnastroici_password;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nastroica_proffil);
        imnasr_photo = findViewById(R.id.nasr_photo);
        ibglavn_6 = findViewById(R.id.glavn_6);
        ibizbrn_6 = findViewById(R.id.izbrn_6);
        ibcarzinca_6 = findViewById(R.id.carzinca_6);
        ibprof_6 = findViewById(R.id.prof_6);
        btnsohran_izmenenia = findViewById(R.id.sohran_izmenenia);
        textnastroici_imia = findViewById(R.id.nasroici_imia);
        textnastroici_email = findViewById(R.id.nasroici_email);
        textnastroici_password = findViewById(R.id.nasroici_password);

        ibglavn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(nasroica_proffil.this, shop.class);
                startActivity(intent);
            }
        });
        ibizbrn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(nasroica_proffil.this, izbrannoe.class);
                startActivity(intent);
            }
        });
        ibcarzinca_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(nasroica_proffil.this, carzina.class);
                startActivity(intent);
            }
        });
        ibprof_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(nasroica_proffil.this, shop.class);
                startActivity(intent);
            }
        });
        imnasr_photo.setOnClickListener(v -> openImageChooser());

    }
    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");                   // тип данных - изображения
        intent.setAction(Intent.ACTION_GET_CONTENT); // открыть файловый менеджер
        startActivityForResult(Intent.createChooser(intent, "Выберите фото"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            // Ставим фото в ImageButton
            imnasr_photo.setImageURI(imageUri);
        }
    }
}
