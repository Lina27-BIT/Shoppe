package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class carzina extends AppCompatActivity {
    private ImageButton imbtnglavn_3;
    private ImageButton imbtnizbrn_3;
    private ImageButton imbtncarzinca_3;
    private ImageButton imbtnprof_3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.carzina);
       imbtnglavn_3 = findViewById(R.id.glavn_3);
        imbtnizbrn_3 = findViewById(R.id.izbrn_3);
        imbtncarzinca_3 = findViewById(R.id.carzinca_3);
        imbtnprof_3= findViewById(R.id.prof_3);

        imbtnprof_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(carzina.this, proffil.class);
                startActivity(intent);
            }
        });
        imbtnizbrn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(carzina.this, izbrannoe.class);
                startActivity(intent);
            }
        });
        imbtnglavn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(carzina.this, shop.class);
                startActivity(intent);
            }
        });
        imbtncarzinca_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(carzina.this, carzina.class);
                startActivity(intent);
            }
        });
    }
}
