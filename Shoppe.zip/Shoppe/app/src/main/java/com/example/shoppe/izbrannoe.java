package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class izbrannoe extends AppCompatActivity {
    private ImageButton imbtglavn_2;
    private ImageButton imbtizbrn_2;
    private ImageButton imbtcarzinca_2;
    private ImageButton imbtprof_2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.izbrannoe);
        imbtglavn_2 = findViewById(R.id.glavn_2);
        imbtizbrn_2 = findViewById(R.id.izbrn_2);
        imbtcarzinca_2 = findViewById(R.id.carzinca_2);
        imbtprof_2 = findViewById(R.id.prof_2);

        imbtprof_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(izbrannoe.this, proffil.class);
                startActivity(intent);
            }
        });
        imbtcarzinca_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(izbrannoe.this, carzina.class);
                startActivity(intent);
            }
        });
        imbtglavn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(izbrannoe.this, shop.class);
                startActivity(intent);
            }
        });
        imbtizbrn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(izbrannoe.this, izbrannoe.class);
                startActivity(intent);
            }
        });
    }
}
