package com.example.shoppe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class create_account extends AppCompatActivity {
    private ImageButton photoicon;
    private EditText textemail;
    private EditText textpassword;
    private EditText textpovtor;
    private EditText textnomert;
    private Button btngotovo;
    private Button btnotmena1;
    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account);

        photoicon = findViewById(R.id.photo_icon);
        textemail = findViewById(R.id.email);
        textpassword = findViewById(R.id.password);
        textpovtor = findViewById(R.id.povtor_password);
        textnomert = findViewById(R.id.nomer_t);
        btngotovo = findViewById(R.id.gotovo);
        btnotmena1 = findViewById(R.id.otmena1);

        photoicon.setOnClickListener(v -> openImageChooser());

        btngotovo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateInputs();
            }
        });
        btnotmena1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(create_account.this, start.class);
                startActivity(intent);
            }
        });
    }
    private void validateInputs(){
        String email = textemail.getText().toString().trim();
        String password = textpassword.getText().toString().trim();
        String povtor_password = textpovtor.getText().toString().trim();
        String nomer_t = textnomert.getText().toString().trim();

        if (email.isEmpty()){
            Toast.makeText(this, "Введите почту", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!email.contains("@") || !email.contains(".")){
            Toast.makeText(this,"Введите правильную почту", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 8) {
            Toast.makeText(this, "Пароль должен содержать не менее 8 символов", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!password.matches(".*[!@#$%^&*()_+={};':|,.<>/?].*")){
            Toast.makeText(this, "Пароль должен содержать хотя бы один спец. символ", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!password.equals(povtor_password)) {
            Toast.makeText(this, "Пароли не совпадают", Toast.LENGTH_SHORT).show();
            return;
        }
        if (nomer_t.isEmpty()) {
            Toast.makeText(this, "Введите номер телефона", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!nomer_t.matches("\\d{10,11}")) {
            Toast.makeText(this, "Введите корректный номер телефона (10-11 цифр)", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Все данные корректны", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(create_account.this, sozdanie_pincoda.class);
        startActivity(intent);
    }
    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");                   // тип данных - изображения
        intent.setAction(Intent.ACTION_GET_CONTENT); // открыть файловый менеджер
        startActivityForResult(Intent.createChooser(intent, "Выберите фото"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            // Ставим фото в ImageButton
            photoicon.setImageURI(imageUri);
        }
    }
}

