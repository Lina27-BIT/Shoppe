package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class new_password extends AppCompatActivity {
    private Button btnsoxran;
    private Button btnotmena_5;
    private EditText txtnewpassword;
    private EditText txtpovter_password2;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_password);
        btnsoxran = findViewById(R.id.soxran);
        btnotmena_5 = findViewById(R.id.otmena5);
        txtnewpassword = findViewById(R.id.newpassword);
        txtpovter_password2 = findViewById(R.id.povtor_password_2);

        btnotmena_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(new_password.this, password.class);
                startActivity(intent);
            }
        });
        btnsoxran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(new_password.this, proffil.class);
                startActivity(intent);
            }
        });
    }
}
