package com.example.shoppe;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class new_password extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_password);
    }
}
