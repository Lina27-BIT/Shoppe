package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class vostanov_password2 extends AppCompatActivity {
    private Button btnotpr;
    private Button btnotmena4;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vostanov_password2);
        btnotpr = findViewById(R.id.otpr_eshe_raz);
        btnotmena4 = findViewById(R.id.otmena4);

        btnotmena4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(vostanov_password2.this, vostanov_password.class);
                startActivity(intent);
            }
        });
    }
}
