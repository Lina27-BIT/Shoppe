package com.example.shoppe;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class vostanov_password2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vostanov_password2);
    }
}
