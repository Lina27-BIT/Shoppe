package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class password extends AppCompatActivity {
    private EditText vvodpassword;
    private Button zabpassword;
    private Button btndalee2;
    private final String correctPassword = "";
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.passwor);

        btndalee2 = findViewById(R.id.dalee2);
        zabpassword = findViewById(R.id.zab_password);
        vvodpassword = findViewById(R.id.vvod_password);

        btndalee2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredPassword = vvodpassword.getText().toString();

                if (enteredPassword.equals(correctPassword)) {
                    // Пароль верный - переходим на следующий экран
                    Intent intent = new Intent(password.this, shop.class);
                    startActivity(intent);
                } else {
                    // Пароль неправильный - показываем сообщение
                    Toast.makeText(password.this, "Пароль не правильный", Toast.LENGTH_SHORT).show();
                }
            }
        });
        zabpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(password.this, vostanov_password.class);
                startActivity(intent);
            }
        });
    }
}
