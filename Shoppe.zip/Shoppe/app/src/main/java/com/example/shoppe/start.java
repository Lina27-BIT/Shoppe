package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class start extends AppCompatActivity {
private Button btnzareg;
private Button btnestacc;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);
       btnzareg = findViewById(R.id.btn_zareg);
       btnestacc = findViewById(R.id.btn_estacc);
        // Обработчик нажатия кнопки "Зарегистрироваться"
        btnzareg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(start.this, create_account.class);
                startActivity(intent);
            }
        });
        // Обработчик нажатия кнопки "У меня уже есть аккаунт"
        btnestacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(start.this, avtorizachia.class);
                startActivity(intent);
            }
        });
    }
}
