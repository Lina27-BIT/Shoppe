package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class vostanov_password extends AppCompatActivity {
    private Button btndalee3;
    private Button btnotmena3;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vostanov_passwod);
        btndalee3 = findViewById(R.id.dalee3);
        btnotmena3 = findViewById(R.id.otmena3);

        btndalee3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(vostanov_password.this, vostanov_password2.class);
                startActivity(intent);
            }
        });
        btnotmena3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(vostanov_password.this, password.class);
                startActivity(intent);
            }
        });
    }
}
