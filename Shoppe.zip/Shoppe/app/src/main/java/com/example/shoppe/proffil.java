package com.example.shoppe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class proffil extends AppCompatActivity {
    private ImageButton imglavn_4;
    private ImageButton imizbrn_4;
    private ImageButton imcarzinca_4;
    private ImageButton improf_4;
    private ImageButton btnnastroica;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.proffil);
        imglavn_4 = findViewById(R.id.glavn_4);
        imizbrn_4 = findViewById(R.id.izbrn_4);
        imcarzinca_4 = findViewById(R.id.carzinca_4);
        improf_4 = findViewById(R.id.prof_4);
        btnnastroica = findViewById(R.id.nastroica);

        improf_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(proffil.this, shop.class);
                startActivity(intent);
            }
        });
        imizbrn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(proffil.this, izbrannoe.class);
                startActivity(intent);
            }
        });
        imcarzinca_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(proffil.this, carzina.class);
                startActivity(intent);
            }
        });
        imglavn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(proffil.this, shop.class);
                startActivity(intent);
            }
        });
        btnnastroica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(proffil.this, nasroica_proffil.class);
                startActivity(intent);
            }
        });
    }
}
